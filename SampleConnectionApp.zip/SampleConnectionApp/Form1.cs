﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient; // This using is important when working with SQL databses.

namespace SampleConnectionApp
{
    public partial class Form1 : Form
    {

        SqlConnection con = new SqlConnection("Data Source=MSI;Initial Catalog=SampleStudentsProfiles;Integrated Security=True"); // Opening SQL connection

        public Form1()
        {
            InitializeComponent();
        }

        // Method that reloads (refreshes the form).
        private void Form1_Load(object sender, EventArgs e)
        {
            // TODO: This line of code loads data into the 'sampleStudentsProfilesDataSet.Student' table. You can move, or remove it, as needed.
            Form1_Load();

        }

        // Simply a toolstrip menu item that says add new student and displays a single panel.
        private void addNewStudentToolStripMenuItem_Click(object sender, EventArgs e)
        {
            InsertPanel.Visible = true; // Makes the InsertPanel visible when the user clicks on "Add New Student".
        }

        // Button to insert student information.
        private void button1_Click(object sender, EventArgs e)
        {
            con.Open(); // Opens established SQL database connection.

            SqlCommand cmd = con.CreateCommand(); // Creates a SQL Command.
            cmd.CommandType = CommandType.Text; // States which format the command will be in.
            cmd.CommandText = "Insert into Student values('"+txtName.Text+"'," + // A simple hardcoded insert query to insert values in the columns. --Start
                                                         "'" +txtParentName.Text+"'," +
                                                         "'"+txtDepartment.Text+"'," +
                                                         "'"+txtBatch.Text+"'," +
                                                         "'"+txtRollNo.Text+"'," +
                                                         "'"+txtEmail.Text+"'," +
                                                         "'"+txtContactNo.Text+"')"; // --End
            cmd.ExecuteNonQuery(); // Executes the SQL command.
            con.Close(); // Closes the established SQL databse connection.

            MessageBox.Show("Student added successfully."); // Shows a MessageBox that states that the student was added successfully.

            Form1_Load(); // Reloads the form, this refreshes the table. 
        } 

        // Reloads the form's information.
        private void Form1_Load()
        {
            this.studentTableAdapter.Fill(this.sampleStudentsProfilesDataSet.Student);
        }

        // Enabling the datagrid to view the data
        private void btnDisplayData_Click(object sender, EventArgs e)
        {
            dataGridView1.Visible = true; // Displays the datagrid as true which means it will show all the data.
        }
    }
}
